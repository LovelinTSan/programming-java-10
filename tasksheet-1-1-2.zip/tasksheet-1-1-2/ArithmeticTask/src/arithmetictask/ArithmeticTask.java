/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arithmetictask;

/**
 *
 * @author Lovelin Tan
 */
public class ArithmeticTask 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
    // Using + operator and *=, +=, -=, compound operators    
        int a = 1, b = 2, result;
        result = a + b; // simple assignment operator
        a*=b; 
        a+=b; 
        a-=b;
        
        System.out.println("The sum of a + b = "+result);
        System.out.println(a*=b); // output should be a*b=2; a=2*2; answer: 4
        System.out.println(a >= b);
        
        //using /= operator
        //using %= operator
        //using &= operator
        //using ^= operator
        //using != operator
        //using <<= operator
        //using >>= operator
        //using >>>= operator
       
        
        /*int result = 1 + 2; // result is now 3
        System.out.println(result);

        result = result - 1; // result is now 2
        System.out.println(result);

        result = result * 2; // result is now 4
        System.out.println(result);

        result = result / 2; // result is now 2
        System.out.println(result);

        result = result + 8; // result is now 10
        result = result % 7; // result is now 3
        System.out.println(result);*/

    }
}